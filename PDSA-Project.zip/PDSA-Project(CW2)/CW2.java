//package cw2;
import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  
import java.text.SimpleDateFormat;

class Pizza
{
	int head, tail;
	 public static int tot_Pizzaprice=0,tot_Pizzaqty=0;
      	Scanner s =new Scanner(System.in);

    	public  Pizza()
    	{
        		head=0;
        		tail=0;      
    	} 
  	int order;
	int qty[];

    	public void  input()
    	{
    	System.out.print("Enter the number of Orders for Pizza:");
    	order = s.nextInt();
      	  qty = new int[order];
        	for(tail=0; tail<order;tail++)
      	{   
            		System.out.print("Enter Pizza Quantity for Order "+(tail+1)+" : ");
            		qty[tail]=s.nextInt();
       	}
	}

	public void PizzaOrdersCompleted()
	{ 
        	System.out.println("\n"); 
        	System.out.println("  ***** Pizza Orders Completed ******"); 
        	for(int head=0; head<tail;head++)
        	{
            		System.out.println("   Completed Order "+(head+1)+" : "+  qty[head]+" Pizza");         
        	}
	}

	public void sortedPizzaQuantity() //Bubble Sort
	{ 
     	System.out.print("\n");
	System.out.println("   **** Sorted list of Today Sold Pizza Quantity ****");  
    	int temp1=0; 
   	for (int i = 0; i < ( order - 1 ); i++) 
    	{
      		for (int j = 0; j < order - i - 1; j++) 
      		{
        			if (qty[j] >qty[j+1]) 
        			{
           				temp1 = qty[j];
           				qty[j] = qty[j+1];
           				qty[j+1] = temp1;
        			}
      		}
    	}
 	 for (int i = 0; i < order; i++) 
	{
      		System.out.println("		   "+qty[i]);
		tot_Pizzaqty=tot_Pizzaqty+qty[i];
	}
	}

	int prices[];
	public void priceCal()
	{
	int price=1500;
	 prices=new int[order];
  	System.out.println("\n");  
     	System.out.println("   **** Prices for Pizza Orders ****");  
        	for(int c=0; c<order;c++)
        	{  
           		prices[c]=price*qty[c];
          		System.out.println("  Pizza Order "+(c+1)+" Price : "+"Rs."+prices[c]+"/=");
        	}
	}  
	
	public void sortedPizzaPrices() //Selection Sort
	{ 
	System.out.print("\n");
	System.out.println("  **** Sorted list of Today Sold Pizza Prices****");  
	for (int i = 0 ;i< order-1; i++)
	{
        		int min = i;		
        		 for (int j = i+1; j<order; j++)
		{
            			if (prices[j] < prices[min])
			{
            				min = j;
            			}
         		}
         	int temp2 = prices[min];
         	prices[min] = prices[i];
         	prices[i] = temp2;
      	}
      	for (int i = 0 ;i< order; i++)
	{
         		System.out.println("		   "+"Rs."+prices[i]+"/=");
		tot_Pizzaprice=tot_Pizzaprice+prices[i];
	}
		
	}		
}
class Juice	
{  
	int head, tail;
	public static  int tot_Juiceprice=0,tot_Juiceqty=0;
      	Scanner s =new Scanner(System.in);
    	public  Juice()
    	{
        		head=0;
        		tail=0; 
    	} 
   	int order;
	int qty[];
	
	 public void input()
	{
	System.out.print("\n");
    	System.out.print("Enter the number of Orders for Juice:");
    	order = s.nextInt();
      	qty= new int[order];
   	for(tail=0; tail<order;tail++)
      	{
            		System.out.print("Enter Juice Quantity for Order "+(tail+1)+" : ");
            		qty[tail]=s.nextInt();
        	}
	}
	
	public void juiceOrdersCompleted()
	{
          	System.out.println("\n"); 
        	System.out.println("  ***** Juice Orders Completed ******"); 
        	for(int head=0; head<tail;head++)
        	{
            	System.out.println("   Completed Order "+(head+1)+" : "+  qty[head]+" Juice");         
        	}
	}

	public void sortedJuiceQuantity() //Selection Sort
	{
  	System.out.print("\n");
	System.out.println("  **** Sorted list of  Today Sold Juice Quantity****");  
    	int temp1=0; 
	for (int i = 0 ;i< order-1; i++)
	{        int min = i;	
        		 for (int j = i+1; j<order; j++)
		{	
            			if (qty[j] < qty[min])
			{        	
				min = j;
         			}
         		}

         	 	temp1 = qty[min];
       		qty[min] =qty[i];
		qty[i] = temp1;
      	}
      	for (int i = 0 ;i< order; i++)
	{
         		System.out.println("		   "+qty[i]);
		tot_Juiceqty=tot_Juiceqty+qty[i];
	}
	}

	int jprices[];
	public void priceCal()
	{
	 int price=200;
	int c;
	jprices=new int[order];
     	System.out.println("\n");  
     	System.out.println("  **** Prices for Juice Orders ****");  
        	for(c=0; c<order;c++)
        	{
         	jprices[c]=price*qty[c];
          	System.out.println("  Juice Order "+(c+1)+" Price : "+"Rs."+jprices[c]+"/=");
        	}
	}
	
	public void sortedJuicePrice() // Bubble Sort
	{
	System.out.print("\n");
	System.out.println("  **** Sorted list of Today Sold Juice Prices****");  
	int temp1=0; 
   	for (int i = 0; i < ( order - 1 ); i++) 
    	{
      		for (int j = 0; j < order - i - 1; j++) 
      		{
        			if (jprices[j] >jprices[j+1]) 
        			{
           				temp1 = jprices[j];
           				jprices[j] = jprices[j+1];
           				jprices[j+1] = temp1;
        			}
      		}
    	}
 	 for (int i = 0; i < order; i++) 
	{
      		System.out.println("		   "+"Rs."+jprices[i]+"/=");
		tot_Juiceprice=tot_Juiceprice+jprices[i];
	}
	}	
}
class Shop 
{	
	public static int NetTotal;
	public static void displaySummary(int a,int b)
	{	
		Pizza.tot_Pizzaprice=a;
		Juice.tot_Juiceprice=b;
		int summary[] = new int[2];
		summary[0] = a;
		summary[1] = b;
		NetTotal=summary[0]+summary[1];
		System.out.println("			Porshia Pizza Hut & Juice Bar Income:		Rs."+NetTotal+"/=");
		int x=0;
  		int temp1=0;  	//Bubble Sort
   		for (int i = 0; i < ( 2 - 1 ); i++) 
    		{
      			for (int j = 0; j < 2 - i - 1; j++) 
      			{
        				if (summary[j] >summary[j+1]) 
        				{
           					temp1 = summary[j];
           					summary[j] = summary[j+1];
           					summary[j+1] = temp1;
					x=2;
        				}
      			}
    		}
		if(x==2)
		{
		System.out.println("			Most Sold Food Type:"+"				"+"Pizza"); 
		System.out.println("				& Income from it:   			Rs."+summary[1]+"/=") ;
		}
		else
		{
		System.out.println("			Most Sold Food Type:"+"				"+"Juice ");
		System.out.println("				Income from it:   			Rs."+summary[1]+"/=") ;
		}
	}		
}
class CW2
{	
		public static void main(String[] args)
    		{
		
       		System.out.println("      			 ***** Porshia Pizza Hut & Juice Bar *****");   
      		Pizza b = new Pizza();
        		b.input();
		b.priceCal();
		b.PizzaOrdersCompleted();
		b.sortedPizzaQuantity();
		b.sortedPizzaPrices();

		Juice c = new Juice();
   		c.input();
		c.priceCal();
		c.juiceOrdersCompleted();
		c.sortedJuiceQuantity();		
		c.sortedJuicePrice();
 	
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
   		LocalDateTime now = LocalDateTime.now();  
		
		Date date=new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");  
    	String strDate = formatter.format(date);  		
		
		System.out.println("\n"); 	
		System.out.println("		****** Porshia Pizza Hut & Juice Bar Daily Report as @ "+strDate+ " ******"); 
		System.out.println("			Sold Pizza Quantity: "+"				"+Pizza.tot_Pizzaqty +" Pizza");
		System.out.println("			Pizza Hut Income:"+"				"+"Rs."+Pizza.tot_Pizzaprice+"/=");
		System.out.println("			Sold Juice Quantity: "+"				"+Juice.tot_Juiceqty +" Juice");	
		System.out.println("			Juice Bar Income:"+"				"+"Rs."+Juice.tot_Juiceprice+"/=");
		Shop d =new Shop();
		d.displaySummary(Pizza.tot_Pizzaprice,Juice.tot_Juiceprice);
		System.out.println("\n");
		System.out.println("						"+"Printed on:"+dtf.format(now)+"	"+"by:Kavith Maduja");
	}
}
 